// import React from 'react';
// import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
// import Board from '../components/Board';
// import WriteBoard from '../components/WriteBoard';
// import BoardComment from '../components/BoardComment';

// const BoardPage = () => {
//   return (
    
//     // <Router>
//     //   <Routes>
//     //     <Route path="/" element={<Board />} />
//     //     <Route path="/write" element={<WriteBoard />} />
//     //     <Route path="/comments" element={<BoardComment />} />
//     //   </Routes>
//     // </Router>
//   );
// };

// export default BoardPage;